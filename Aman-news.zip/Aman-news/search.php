<?php include 'header.php'; ?>
    <div id="main-content">
      <div class="container">
        <div class="row">
        <?php include 'searchbox.php'; ?>
            <div class="col-md-8">
                <!-- post-container -->
                <div class="post-container">
                    <h2 class="page-heading"></h2>
                            <?php
                                include "config.php";     
                                if(isset($_GET["search"]) ){
                                $search_term = $_GET["search"];
                                if(empty($search_term)){
                                   header("Location: {$hostname}index.php");
                                }
                            }
                                 $limit = 3;
                                if(isset($_GET['page']) ){
                                    $page = $_GET["page"];
                                }else{
                                    $page = 1;
                                }
                                $offset = ($page -1) * $limit;
            
                                $offset = ($page -1) * $limit;  
                                $sql2 = "SELECT post.post_id, post.title,post.description, post.category, post.post_date,
                                        category.category_name, category.category_id, user.username, user.user_id, post.post_img FROM post
                                        LEFT JOIN category ON post.category = category.category_id 
                                        LEFT JOIN user ON post.author = user.user_id
                                        WHERE post.title LIKE '%$search_term%'
                                        ORDER BY post_id DESC
                                        LIMIT {$offset}, {$limit}";

                                            $resul2 = mysqli_query($conn, $sql2) or die("Query failed."); 
                                            if(mysqli_num_rows($resul2) > 0){
                                            ?>
                                        <h2 class="page-heading">Matching Records Founded : <?php echo $search_term ?></h2>
                                        
                                        <?php   while ($row = mysqli_fetch_assoc($resul2)) {
                                          $all_column = $row['post_img'];
                                          $all_column_array = explode('!', $all_column);
                                          $count = count($all_column_array);
                                          for($i = 0; $i < $count; $i++) {
                                              $extensions =explode('.', $all_column_array[$i]);
                                              $extension = end($extensions);
                                              if ($extension == 'jpeg' || $extension == 'jpg' || $extension == 'png' || $extension == 'gif'){
                                              ?>  
                                            
                            <div class="post-content">
                            <div class="row">
                            <div class="col-md-4">
                            <a class="post-img" href="single.php?id=<?php echo $row['post_id'] ?>"><img src="admin/upload/<?php echo $all_column_array[$i];?>" alt=""></a>
                             </div>
                                <div class="col-md-8">
                                    <div class="inner-content clearfix">
                                        <h3><a href='single.php?id=<?php echo $row['post_id'] ?>'><?php echo $row['title']?></a></h3>
                                        <div class="post-information">
                                        <span>
                                            <i class="fa fa-tags" aria-hidden="true"></i>
                                            <a href='category.php?id=<?php echo $row['category_id']?>'><?php echo $row['category_name']?></a>
                                            </span>
                                            <span>
                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                <a href='author.php?aid=<?php echo $row['user_id']; ?>'><?php echo $row['username']?></a>
                                            </span>
                                            <span>
                                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                                <?php echo $row['post_date']; ?>
                                            </span>
                                        </div>
                                        <p class="description">
                                        <?php echo substr($row['description'], 0, 180) . "...."; ?>
                                        </p>
                                     <a class='read-more pull-right' href='single.php?id=<?php echo $row['post_id'] ?>'>read more</a>
                                </div>
                            </div>
                        </div>
                    </div>

             <?php
            }
            break;
        }
    }
                }else{
                    echo "<h1>Record not found.</h1>";
                }
                    $sql1 = "SELECT * FROM post 
                    WHERE post.author LIKE '%{$search_term}%'";
                    $result1 = mysqli_query($conn, $sql1) or die("Query failed");
                    $row1 = mysqli_fetch_array($result1);
                    $limit = 3;
                    $total_records = mysqli_num_rows($result1);
                    $total_pages = ceil($total_records / $limit);
                    echo "<ul class='pagination admin-pagination'>";
                    if($page > 1){
                        echo '<li><a href="search.php?search='. $search_term .'&page='.($page - 1).'">Prev</a></li>';
                    }
                for($i = 1; $i <= $total_pages; $i++) {
                    if($i == $page){
                        $active = "active";
                    }
                    else{
                        $active = "";
                    }
                    echo '<li class="'.$active.'"><a href="search.php?search='. $search_term .'&page='.$i.'">'.$i.'</a></li>';
                }
                    if($total_pages > $page){
                    echo '<li><a href="search.php?search='. $search_term .'&page='.($page + 1).'">Next</a></li>';
                }
                    echo "</ul>";
                
                ?> 
                </div><!-- /post-container -->
            </div>
            <?php include 'sidebar.php'; ?>
        </div>
      </div>
    </div>
<?php include 'footer.php'; ?>
