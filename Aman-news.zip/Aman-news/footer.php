<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/font-awesome.css">
    <link rel="stylesheet" href="./css/main.css">
</head>
<body>
    <div class="footer">
<div id ="footer">
    <div class="social-media">

            <div class="icon">
                <h3>Visit us on Social media</h3>
            </div>
            <div class="icon">
                <a href="https://www.facebook.com/profile.php?id=100073921591088&mibextid=ZbWKwL"><img src="./images/facebook (4).svg" alt=""></a>
                <p><a href="https://www.facebook.com/profile.php?id=100073921591088&mibextid=ZbWKwL">Visit our facebook page</a></p>
            </div>
            <div class="icon">
                <a href="https://youtu.be/1DIXaV6CXSc?si=wVnC3O8wD_P5oIen"><img src="./images/youtube (2).svg" alt=""></a>
                <p> <a href="https://youtu.be/1DIXaV6CXSc?si=wVnC3O8wD_P5oIen"> Visit our Youtube channel</a></p>
            </div>
            <div class="icon">
                <a href="https://www.tiktok.com/@sohrabkhan_550?r=1&_d=e0fhhilc431495&sec_uid=MS4wLjABAAAAAWtdvL5FaZD8HdUZf7cD6mlxCXOKzAUHbg_wsRSDEFI7c2x5xJSebeOLQLzgCsC&share_author_id=7116524487822312453&sharer_language=en&source=h5_m&u_code=e2gmgclikikkam&timestamp=1705300156&user_id=7116524487822312453&sec_user_id=MS4wLjABAAAAAWtdvL5FaZD8HdUZf7cD6mlxCXOKzAUHbg_wsRSDEFI7c2x5xJSebeOLQLzgCsC_&utm_source=copy&utm_campaign=client_share&utm_medium=android&share_iid=7304940293089265414&share_link_id=30300789-1568-4d78-aef6-b730086938dc&share_app_id=1233&ugbiz_name=ACCOUNT&ug_btm=b8727%2Cb0229&social_share_type=5&enable_checksum=1"><img src="./images/tiktok (1).svg" alt=""></a>
                <p><a href="https://www.tiktok.com/@sohrabkhan_550?r=1&_d=e0fhhilc431495&sec_uid=MS4wLjABAAAAAWtdvL5FaZD8HdUZf7cD6mlxCXOKzAUHbg_wsRSDEFI7c2x5xJSebeOLQLzgCsC&share_author_id=7116524487822312453&sharer_language=en&source=h5_m&u_code=e2gmgclikikkam&timestamp=1705300156&user_id=7116524487822312453&sec_user_id=MS4wLjABAAAAAWtdvL5FaZD8HdUZf7cD6mlxCXOKzAUHbg_wsRSDEFI7c2x5xJSebeOLQLzgCsC_&utm_source=copy&utm_campaign=client_share&utm_medium=android&share_iid=7304940293089265414&share_link_id=30300789-1568-4d78-aef6-b730086938dc&share_app_id=1233&ugbiz_name=ACCOUNT&ug_btm=b8727%2Cb0229&social_share_type=5&enable_checksum=1">Visit our tiktok account</a></p>
            </div>
            <div class="icon">
                <a href="https://www.instagram.com/sohrabkhan_5?igsh=MTlqbHl2Z3M5eTE3eQ=="><img src="./images/instagram (1).svg" alt=""></a>
                <p><a href="https://www.instagram.com/sohrabkhan_5?igsh=MTlqbHl2Z3M5eTE3eQ==">Visit our instagram account</a></p>
            </div>
            <div class="icon">
                <a href="https://twitter.com/shahkhalid55777"><img src="./images/twitter (1).svg" alt=""></a>
                <p><a href="https://twitter.com/shahkhalid55777">Visit our twitter account</a></p>
            </div>
        </div>
        <div class="contact">
            <h3>Contact Our team</h3>
            <div class="cont-icon">
                <a href="tel:03038700715"><img src="./images/phone-solid (1).svg" alt=""></a>
                <a href="tel:03038700715"><p>Call Us</p></a>
            </div>
            <div class="cont-icon">
                <a href="mailto:www.abdulwahid89045@gmail.com"><img src="./images/envelope-solid.svg" alt=""></a>
                <a href="mailto:www.abdulwahid89045@gmail.com"><p>Email Us</p></a>
            </div>
            <div class="cont-icon">
                <a href="https://chat.whatsapp.com/EssNfWalY8W10vIS0BJaXK "><img src="./images/whatsapp (1).svg" alt=""></a>
                <a href="https://chat.whatsapp.com/EssNfWalY8W10vIS0BJaXK "><p>Whatsapp us</p></a>
            </div>
        </div>
        <div class="about about-us">
        <h3>About Us</h3>
             <p> we created Aman News channel to help our socity. due to this.
            we are aware of all kinds of problem in  distant areas and we will share the from
            our website. for sharinng the news we have group of reporters.</p>
            <a href="about.php"><h4> <button class="btn btn-success">Read More...</button></h4></a>
        </div>

        <div class="about">
            <h3>Leave a Comment</h3>
            <form action="index.php">
            <div class="form-group">
                <label for="exampleInputPassword1"> Email</label><br>
                <input class="email" type="email" name="email"  class="form-control" id="exampleInputUsername" value>
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1"> Comment</label><br>
                <textarea class="comment" name="postdesc" class="form-control"  required rows="4">

                </textarea>
            </div>

            <input type="submit" name="login" class="btn btn-primary btn-success" value="Submit" />
            </form>
        </div>
        
    </div>
<div class="team">
        <p>Powered by <a href="">Abdul wahid</a> | <a href="">Shah Khalid</a> | <a href="">Zain Ul Abideen</a></p>

</div>
</div>
</body>
</html>
