<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>News</title>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="css/font-awesome.css">
    <!-- Custom stlylesheet -->
    <link rel="stylesheet" href="./css/main.css">
    <script src="./JS/jquery.min.js"></script>
</head>
<script src="./main.js"></script>
<body>
<!-- HEADER -->
<div id="main-container">
  <header>
    <video autoplay muted loop id="main-video">
      <source src="./images/background.mp4">
    </video>        
</header>
<!-- /HEADER -->
<!-- Menu Bar -->
<div id="menu-bar">
            <div class="arrow">
                <h4 id="bar-line" class="hide"  onclick="arrow()"><img src="./images/bars-solid.svg" alt=""></h4>
                <h4 id="bar-down"  onclick="arrow()"><img src="./images/arrowdown.png" alt=""></h4>
            </div>
            <div id="links">
                <?php
                if(isset($_GET['id'])){
                    $cat_id = $_GET['id'];
                }else{
                    $cat_id = 1;
                }

                    include "config.php";
                    $sql = "SELECT * FROM category WHERE post > 0";
                    $result = mysqli_query($conn, $sql);
                    ?>
                    <ul class='menu'>
                        <li><a href="<?php echo $hostname ?>">Home</a></li>
                        <?php
                if(mysqli_num_rows($result) > 0){

                 while($row = mysqli_fetch_assoc($result)){
                    if($row['category_id'] == $cat_id){
                        $active = "active";
                    }else{
                        $active = "";
                    }
                    echo "<li><a class='{$active}' href='category.php?id={$row['category_id']}'>{$row['category_name']}</a></li>";
                }
                ?>
                <?php
                if (isset($_GET['category_name'])){
                    $category = $_GET['category_name'];
                    if($category == 'videos'){
                        $actives = "active";
                    }else{
                        $actives = "";
                    }
                }
                ?>
               <li ><a class='<?php echo $actives ?>' href='videos.php?category_name=videos'>Videos</a></li>;
                </ul>
                <?php }else{
                    echo "<h1> No category found</h1>";
                    }?>
            </div>
</div>
<script>
function arrow(){
   
    var element = document.getElementById('links');
    element.classList.toggle('hide');
    var element1 = document.getElementById('bar-line');
    element1.classList.toggle('hide');
    var element2 = document.getElementById('bar-down');
    element2.classList.toggle('hide');
    
    // if(window.outerWidth > 992){
    //     var element = document.getElementById('links');
    // element.classList.toggle('hide');
    // }
}
</script>
</body>
</html>
<!-- /Menu Bar -->
