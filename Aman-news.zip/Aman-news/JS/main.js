$(document).ready(function(){
   $('.multiple-feature-image').addClass('opacity');
    $('.multiple-feature-image').click(function(){
        let slideCount = $('.multiple-feature-image').length;
         let currentIndex = 0;
         // $('.single-feature-image').hide();
         // $('.first_image').show();

         $('.multiple-feature-image').on('click', function () {
            currentIndex = $(this).index();
            showSlide(currentIndex);
         });
         function showSlide(index) {
            $('.single-feature-image').hide().removeClass('first_image');
            $('.multiple-feature-image').removeClass('active-dot');
            $('.multiple-feature-image').removeClass('active');
            $('.multiple-feature-image').addClass('opacity');
            $('.single-feature-image').eq(index).show().addClass('first_image');
            $('.multiple-feature-image').eq(index).addClass('active-dot');
            $('.multiple-feature-image').eq(index).removeClass('opacity');
         }
         showSlide(currentIndex);;
    });

});
