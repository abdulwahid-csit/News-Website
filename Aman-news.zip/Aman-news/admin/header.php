<?php
include "config.php";
session_start();
if(!isset($_SESSION['username'])){
    header("Location: {$hostname}admin/index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>ADMIN Panel</title>
        <!-- Bootstrap -->
        <link rel="stylesheet" href="../css/bootstrap.min.css" />
        <!-- Font Awesome Icon -->
        <link rel="stylesheet" href="../css/font-awesome.css">
        <!-- Custom stlylesheet -->
        <link rel="stylesheet" href="../css/main.css">
    </head>
    <body>
        <!-- HEADER -->
        <div id="header-admin">
            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                    <!-- LOGO -->
                    <div class="col-md-offset-3 col-md-8">
                        <a href="post.php" id="admin-logo"><img class="logo" src="images/aman.jpg"></a>
                    </div>
                    <!-- /LOGO -->
                      <!-- LOGO-Out -->
                    <div class="col-md-offset-9  col-md-3">
                        <a href="" class="admin-logout" style="text-decoration-line: none; color:gold">Hello, <?php echo $_SESSION['username'] ?></a>
                        <a href="logout.php" class="admin-logout">logout</a>
                    </div>
                    <!-- /LOGO-Out -->
                </div>
            </div>
        </div>
        <!-- /HEADER -->
        <!-- Menu Bar start -->
        <div id="admin-menubar">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                       <ul class="admin-menu">
                        <?php
                         if(!isset($_GET['m_id'])){
                            $id = 1;
                        }else{
                            $id = $_GET['m_id'];
                        }
                        if($id == 1){
                            $post = 'active';
                            $video = '';
                            $category = '';
                            $users = '';
                        }elseif($id == 2){
                            $post = '';
                            $video = 'active';
                            $category = '';
                            $users = '';
                        }elseif($id == 3){
                            $category = 'active';
                            $post = '';
                            $video = '';
                            $users = '';
                        }else{
                            $category = '';
                            $post = '';
                            $video = '';
                            $users = 'active';
                            
                        }
                         if($_SESSION['user_role'] == 1){

                            
                        ?>

                        <li>
                            <a class="<?php echo $post ?>" href="post.php?m_id=1">Post</a>
                        </li>
                        <li>
                            <a class="<?php echo $video ?>" href="video.php?m_id=2">Videos</a>
                        </li>
                        <li>
                            <a class="<?php echo $category ?>" href="category.php?m_id=3">Category</a>
                        </li>
                        <li>
                            <a class="<?php echo $users ?>" href="users.php?m_id=4">Users</a>
                        </li>

                      <?php }else{  ?>
                        <li>
                        <a class="<?php echo $post ?>" href="post.php?m_id=1">Post</a>
                        </li>
                        <li>
                            <a class="<?php echo $video ?>" href="video.php?m_id=2">Videos</a>
                        </li>

                    <?php } ?>    
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Menu Bar end -->
