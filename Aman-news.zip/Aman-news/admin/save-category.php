<?php
include "config.php";
session_start();
if(!isset($_SESSION['username'])){
    header("Location: {$hostname}admin/index.php");
}
?>
<?php
include "config.php";
$prv_name = $_GET['prname'];
$new_name = $_POST['cat_name'];
if($prv_name == $new_name){
    header("Location: {$hostname}admin/category.php?m_id=3");
}else{


    $id = $_POST['cat_id'];
    $sql1 = "SELECT * FROM category";
    $result1 = mysqli_query($conn, $sql1) or die("Couldn't execute query");
    $cat_new = strtolower($_POST['cat_name']);
    while($row1 = mysqli_fetch_assoc($result1)){
        if($cat_new === strtolower($row1['category_name'])){
            header("Location: {$hostname}admin/update-category.php?m_id=3&id={$id}&error=1");
            die();  
        }
    }
        $sql3 = "UPDATE category SET category_name = '$cat_new' WHERE category_id = '$id'";
            $result3 = mysqli_query($conn, $sql3);
            header("Location: {$hostname}admin/category.php?m_id=3&error=0");
}
    ?>