<?php
include "config.php";
session_start();
if(!isset($_SESSION['username'])){
    header("Location: {$hostname}admin/index.php");
}
?>

<?php
$post_id = $_GET['id'];
$cat_id = $_GET['c_id'];

$sql1 = "SELECT * FROM post WHERE post_id = $post_id";
$result = mysqli_query($conn, $sql1) or die("query failed.");
$row1 = mysqli_fetch_assoc($result);
unlink("upload/".$row1['post_img']);

if(isset($post_id)){
    include "config.php";
    $sql = "UPDATE category SET post = post - 1 WHERE category_id = '$cat_id';";
    $sql .= "DELETE FROM post WHERE post_id = $post_id";
    $query = mysqli_multi_query($conn, $sql);
    header("Location: {$hostname}admin/post.php?m_id=1");
}

?>