<?php 
include 'header.php';
include 'config.php';
if (isset($_POST['Next'])){
if($_POST['post_type'] == '1'){
    header("Location: {$admin_host}add-post.php");
}else{
    header("Location: {$admin_host}add-video-post.php");
}
}
?>
<div class="container">
    <div class="row">
        <div class="post-contents">
         <div class="col-md-offset-8 col-md-4 text-center">
            <form action="<?php $_SERVER['PHP_SELF']?>" method="POST" autocomplete="off">
                <div class="form-group form-controle">
                    <h4><b> Select post type</b></h4>
                <label for="exampleInputCategory"></label>
                    <select style="width:300px; height:40px; font-size:20px" name="post_type" id="">
                            <option value="1">Image</option>
                            <option value="2">Video</option>
                    </select>
                    </div>
                      <input href="" type="submit" name="Next" class="btn btn-primary" value="Next" required />
                 
                </div>
            </form>
         </div>
        </div>
    </div>
</div>
