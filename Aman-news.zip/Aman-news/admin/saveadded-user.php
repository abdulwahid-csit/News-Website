<?php
    $pr_username = strtolower($_GET['username']);
    include "config.php";
    if(isset($_POST["save"])){
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = md5($_POST['password']);
    $role = $_POST['role'];
    $user_id = $_GET['id'];
    $sql1 = "SELECT * FROM user";
    $query1 = mysqli_query($conn, $sql1);
    while($row = mysqli_fetch_assoc($query1)){
        if($row['username'] == $username){
            header("Location: {$hostname}admin/add-user.php?m_id=4&error=1&id={$user_id}");
            die();
    }
}

    $sql = "INSERT INTO user(first_name, last_name, username, password, role)
                        VALUES('{$fname}', '{$lname}', '{$username}', '{$password}', {$role} )";
    $query = mysqli_query($conn, $sql) or die("Cann't Insert into data base.");
    header("Location: {$hostname}admin/users.php?m_id=4&error=no");
 }
?>