<?php
include "config.php";
session_start();
if(!isset($_SESSION['username'])){
    header("Location: {$hostname}admin/index.php");
}
?>

<?php
$allfiles = "";
$separator = '.';
if(isset($_FILES['fileToUpload'])){
    foreach ($_FILES['fileToUpload']['name'] as $key => $name) {
        $name .= basename($_FILES['fileToUpload']['name'][$key]);
        $file_name = $_FILES['fileToUpload']['name'][$key];
        $file_type = $_FILES['fileToUpload']['type'][$key];
        $file_size = $_FILES['fileToUpload']['size'][$key];
        $tmp_name = $_FILES['fileToUpload']['tmp_name'][$key];
        $file_ex = explode($separator, $file_name);
        $file_ext = end($file_ex);
        $saved_ext = array('jpeg','jpg', 'png', 'gif');

if (in_array($file_ext, $saved_ext) === false) {
        $Error =  "Sorry, only jpg, jpeg, png & gif files are allowed.";
        Header("Location: {$admin_host}add-post.php?error=iextension");
}

    if($file_size > 1024 * 1024 * 5){
    Header("Location: {$admin_host}add-post.php?error=isize");
}

move_uploaded_file($tmp_name, "upload/".$file_name);
$allfiles .= $file_name. '!';
}

}
$title = mysqli_real_escape_string($conn, $_POST["post_title"]);
$description = mysqli_real_escape_string($conn, $_POST["postdesc"]);
$category = $_POST["category"];
$date = date("d M, Y");
$author = $_SESSION['user_id'];
$sql = "INSERT INTO post (title, description, category, post_date, author, post_img)
                    VALUES('$title', '$description', '$category', '$date', '$author', '$allfiles');";

$sql .= "UPDATE category SET post = post + 1 WHERE category_id = $category";
if(mysqli_multi_query($conn, $sql)){
    header("Location: {$hostname}admin/post.php?error=post-added");
}else{
    echo "<div class= alert alert-danger>Query Failed!</div>";
}



?>
