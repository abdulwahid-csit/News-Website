<?php include "header.php"; ?>
<?php
if ($_SESSION['user_role'] == 0){
    header("Location: http://localhost/news-template/admin/post.php");
}
?>
<?php
$error = $_GET['error'];
if($error == '1'){
    echo "<div class='alert alert-danger'>This category name is already exists. Please enter a new category name.</div>";
}



if(isset($_GET['id'])){
    include "config.php";
    $id = $_GET['id'];
    $sql = "SELECT * FROM category WHERE category_id = $id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
}

?>

  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <h1 class="adin-heading"> Update Category</h1>
              </div>
              <div class="col-md-offset-3 col-md-6">
                  <form action="save-category.php?prname=<?php echo $row['category_name'] ?>" method ="POST">
                      <div class="form-group">
                          <input type="hidden" name="cat_id"  class="form-control" value="<?php echo $row['category_id']?>" placeholder="">
                      </div>
                      <div class="form-group">
                          <label>Category Name</label>
                          <input type="text" name="cat_name" class="form-control" value="<?php echo $row['category_name']?>"  placeholder="" required> 
                      </div>
                      <input href="" type="submit" name="sumbit" class="btn btn-primary" value="Update" required />
                  </form>
                </div>
              </div>
            </div>
          </div>
<?php include "footer.php"; ?>
