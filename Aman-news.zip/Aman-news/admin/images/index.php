<html>
    <body>
        <h1 style="color: red;">Please login first. Unauthorized users can't acces this file.</h1>
    </body>
</html>