<?php
    if(in_array("", $_FILES['new-image']['name'])) {
        
        echo $allfiles =  $_POST['old_image'];
      
    }
     else{

        $image_array = explode("!", $_POST['new_image']);
        for($i = 0; $i < count($image_array); $i++) {
            print_r($image_array[$i]);
            unlink('upload/'.$image_array[$i]);
        }
        $allfiles = '';
        foreach ($_FILES['new-image']['name'] as $key => $name) {
            $name .= basename($_FILES['new-image']['name'][$key]);
            $file_name = $_FILES['new-image']['name'][$key];
            $file_type = $_FILES['new-image']['type'][$key];
            $file_size = $_FILES['new-image']['size'][$key];
            $tmp_name = $_FILES['new-image']['tmp_name'][$key];
            $file_ex = explode('.', $file_name);
            $file_ext = end($file_ex);
            $saved_ext = array('jpeg','jpg', 'png', 'gif');

    if (in_array($file_ext, $saved_ext) === false) {
            Header("Location: {$admin_host}add-post.php?error=iextension");
    }
    
        if($file_size > 1024 * 1024 * 5){
        Header("Location: {$admin_host}add-post.php?error=isize");
    }
    $allfiles .= $file_name . "!";
   
    move_uploaded_file($tmp_name, "upload/".$file_name);
}
}
L:
    include "config.php";
    $post_id = $_POST["post_id"];
    $title = mysqli_real_escape_string($conn, $_POST["post_title"]);
    $description = mysqli_real_escape_string($conn, $_POST["postdesc"]);
    $category = $_POST["category"];
    $cid = $_POST["cid"];
    $sql = "UPDATE post SET title = '$title', description = '$description', category = '$category', post_img = '$allfiles' WHERE post_id = $post_id";
    if(mysqli_query($conn, $sql)){
        if($_GET['cid'] != $category){
            $cid = $_GET['cid'];
            $sql2 = "UPDATE category SET post = (post - 1) WHERE category_id = $cid;";
            $sql2 .= "UPDATE category SET post = (post + 1) WHERE category_id = $category;";
            mysqli_multi_query($conn, $sql2);
        }
        header("Location: {$hostname}admin/post.php?error=up");
    }else{
        die('cannot execute query');
    }
            
?>