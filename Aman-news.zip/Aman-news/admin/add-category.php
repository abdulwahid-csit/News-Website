<?php include "header.php"; ?>
<?php
if ($_SESSION['user_role'] == 0){
    header("Location: http://localhost/news-template/admin/post.php");
}
?>

  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <h1 class="admin-heading">Add New Category</h1>
              </div>
              <?php
                $error = $_GET["error"];
                if($error == 1){
                    echo "<div class='alert alert-danger'>This category name is already exists. Please enter a new category name.</div>";
                }
              ?>
              <div class="col-md-offset-3 col-md-6">
                  <!-- Form Start -->
                  <form action="<?php $_SERVER['PHP_SELF'] ?>?m_id=3" method="POST" autocomplete="off">
                      <div class="form-group">
                          <label>Category Name</label>
                          <input type="text" name="cat" class="form-control" placeholder="Category Name" required>
                      </div>
                      <input type="submit" name="save" class="btn btn-primary" value="Save" required />
                  </form>
                <?php
                if(isset($_POST['save'])){
                    include "config.php";
                    $category_name = $_POST['cat'];
                    $sql = "SELECT * FROM category";
                    $result = mysqli_query($conn, $sql) or die("can't execute query");
                while ($row = mysqli_fetch_array($result)){
                    $chk_cat_name = $row['category_name'];
                if (strtolower($chk_cat_name) == strtolower($category_name)){
                    header("Location: {$hostname}admin/add-category.php?m_id=3&error=1");
                    die();
                }
                }
                    $sql1 = "INSERT INTO category(category_name) VALUES('$category_name')";
                    $result1 = mysqli_query($conn, $sql1) or die("can't execute query");
                    header("Location: {$hostname}admin/category.php?m_id=3");
            }
                ?>

                  <!-- /Form End -->
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
