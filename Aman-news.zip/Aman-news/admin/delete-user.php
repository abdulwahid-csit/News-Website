<?php
include "config.php";
session_start();
if(!isset($_SESSION['username'])){
    header("Location: {$hostname}admin/index.php");
}
?>

<?php
include "config.php";
$id = $_GET['id'];

$sql = "DELETE FROM user WHERE user_id = $id";
mysqli_query($conn, $sql) or die("Error while delteing the user.");
header("Location: {$hostname}admin/users.php?m_id=4");
?>