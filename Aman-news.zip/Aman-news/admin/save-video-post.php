<?php
include "config.php";
session_start();
if(!isset($_SESSION['username'])){
    header("Location: {$hostname}admin/index.php");
}
?>

<?php
if(isset($_FILES['video'])){
        $video_name = $_FILES['video']['name'];
        $video_type = $_FILES['video']['type'];
        $video_size = $_FILES['video']['size'];
        $video_tmp_name = $_FILES['video']['tmp_name'];
        $file_ex = explode('.', $video_name);
        $file_ext = end($file_ex);

        $saved_ext = array('mpeg','mp4', 'mkv', 'gif', 'hd', 'avi', 'flv', 'tiff');

    if (in_array($file_ext, $saved_ext) === false) {
    Header("Location: {$admin_host}add-video-post.php?error=vextension");
    }
    
    if($video_size > 1024 * 1024 * 300){
    Header("Location: {$admin_host}add-video-post.php?error=vsize");
    }


move_uploaded_file($video_tmp_name, "upload/".$video_name);
}
$title = mysqli_real_escape_string($conn, $_POST["post_title"]);
$description = mysqli_real_escape_string($conn, $_POST["postdesc"]);
$category = $_POST["category"];
$date = date("d M, Y");
$author = $_SESSION['user_id'];
$sql = "INSERT INTO video (v_title, v_description, v_category, v_date, v_author, post_video)
                    VALUES('$title', '$description', '$category', '$date', '$author', '$video_name');";

$sql .= "UPDATE category SET post = post + 1 WHERE category_id = $category";
if(mysqli_multi_query($conn, $sql)){
    header("Location: {$hostname}admin/post.php?error=video_added&m_id=2");
}else{
    echo "<div class= alert alert-danger>Query Failed!</div>";
}



?>
