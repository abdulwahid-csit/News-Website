<?php include "header.php"; ?>
<?php
if (isset($_GET['error'])){
    $error = $_GET['error'];
if($error == 'video_added'){
    echo "<div class='alert alert-success'>Video post is succesfully added.</div>";
}else{
    echo "<div class='alert alert-success'>Video post is succesfully updated.</div>";
}
}
?>
  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-10">
                  <h1 class="admin-heading">All Video Posts</h1>
              </div>
              <div class="col-md-2">
                  <!-- <a class="add-new" href="add-post.php?id=1">add post</a> -->
                  <a class="add-new" href="add-video-post.php?m_id=2">add post</a>
              </div>
              <div class="col-md-12">
              <?php
                    
                    $limit = 5;
                    if(isset($_GET['page1']) ){
                        $page1 = $_GET["page1"];
                    }else{
                        $page1 = 1;
                    }
                    $offset = ($page1 - 1) * $limit;
                    ?>
                  <table class="content-table">
                      <thead>
                          <th>S.No.</th>
                          <th>Title</th>
                          <th>Category</th>
                          <th>Date</th>
                          <th>Author</th>
                          <th>Edit</th>
                          <th>Delete</th>
                      </thead>
                      <tbody>
                        <?php
                        if(!isset($_SESSION['user_id'])){
                            session_start();
                            $user_id =  $_SESSION['user_id'];
                        }else{
                            $user_id =  $_SESSION['user_id'];
                        }
    
                        include "config.php";
                        if($_SESSION['user_role'] == 1){
                        $sql = "SELECT video.v_id, video.v_title, video.v_category, video.v_date,
                                category.category_name, category.category_id, user.username FROM video
                                LEFT JOIN category ON video.v_category = category.category_id 
                                LEFT JOIN user ON video.v_author = user.user_id
                                ORDER BY v_id DESC
                                LIMIT {$offset}, {$limit}";
                        }else{
                            $sql = "SELECT video.v_id, video.v_title, video.v_category, video.v_date,
                            category.category_name, category.category_id, user.username FROM video
                            LEFT JOIN category ON video.v_category = category.category_id 
                            LEFT JOIN user ON video.v_author = user.user_id
                            WHERE video.v_author = $user_id
                            ORDER BY v_id DESC
                            LIMIT {$offset}, {$limit}
                            ";
                        }        
                        $query = mysqli_query($conn, $sql);
                        $s_number =   $offset;
                        while ($row = mysqli_fetch_assoc($query)){

                        
                        $s_number++;
                        ?>
                          <tr>
                              <td class='id'><?php echo $s_number ?></td>
                              <td><?php echo $row['v_title'] ?></td>
                              <td><?php echo $row['category_name'] ?></td>
                              <td><?php echo $row['v_date'] ?></td>
                              <td><?php echo $row['username'] ?></td>
                              <td class='edit'><a href='update-video.php?m_id=2&id=<?php echo $row['v_id']; ?>'><i class='fa fa-edit'></i></a></td>
                              <td class='delete'><a href='delete-video.php?m_id=2&c_id=<?php echo $row['v_category']; ?>&id=<?php echo $row['v_id']; ?>'><i class='fa fa-trash-o'></i></a></td>
                          </tr>
                          <?php } ?>
                          
                      </tbody>

                  </table>
                  <?php
                    $limit = 5;
                    $s_userid = $_SESSION['user_id'];
                    if($_SESSION['user_role'] == 1){
                        $sql2 = "SELECT * FROM video";
                    }else{
                        $sql2 = "SELECT * FROM video WHERE v_author = $s_userid";
                    }
                    $query2 = mysqli_query($conn, $sql2);
                    $total_records = mysqli_num_rows($query2);
                    $total_pages = ceil($total_records / $limit);
                    echo "<ul class='pagination admin-pagination'>";
                    if($page1 > 1){
                        echo '<li><a href="video.php?m_id=2&page1='.($page1 - 1).'">Prev</a></li>';
                    }
                   for($j = 1; $j <= $total_pages; $j++) {
                    if($j == $page1){
                        $active = "active";
                    }
                    else{
                        $active = "";
                    }
                    echo '<li class="'.$active.'"><a href="video.php?m_id=2&page1='.$j.'">'.$j.'</a></li>';
                   }
                   if($total_pages > $page1){
                    echo '<li><a href="video.php?m_id=2&page1='.($page1 + 1).'">Next</a></li>';
                }
                   echo "</ul>";
                  ?>
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
