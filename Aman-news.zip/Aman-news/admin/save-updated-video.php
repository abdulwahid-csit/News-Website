<?php
    if(empty($_FILES['new-image']['name'])) {
        $file_name  = $_POST['old_image'];
    } else{
            $file_name = $_FILES['new-image']['name'];
            $file_type = $_FILES['new-image']['type'];
            $file_size = $_FILES['new-image']['size'];
            $tmp_name = $_FILES['new-image']['tmp_name'];
            $file_ex = explode('.', $file_name);
            $file_ext = end($file_ex);
            $saved_ext = array('jpeg','jpg', 'png', 'gif', '');

    if (in_array($file_ext, $saved_ext) === false) {
            Header("Location: {$admin_host}add-video-post.php?m_id&error=vextension");
    }
    
        if($file_size > 1024 * 1024 * 500){
        Header("Location: {$admin_host}add-video-post.php?m_id=2&error=vsize");
    }
    move_uploaded_file($tmp_name, "upload/".$file_name);
}

    include "config.php";
    $post_id = $_POST["post_id"];
    $title = mysqli_real_escape_string($conn, $_POST["post_title"]);
    $description = mysqli_real_escape_string($conn, $_POST["postdesc"]);
    $category = $_POST["category"];
    $sql = "UPDATE video SET v_title = '$title', v_description = '$description', v_category = '$category', post_video = '$file_name' WHERE v_id = $post_id";
    if(mysqli_query($conn, $sql)){
        if($_GET['v_id'] != $category){
            $v_id = $_GET['v_id'];
            $sql2 = "UPDATE category SET post = (post - 1) WHERE category_id = $v_id;";
            $sql2 .= "UPDATE category SET post = (post + 1) WHERE category_id = $category;";
            mysqli_multi_query($conn, $sql2);
        }
        header("Location: {$hostname}admin/video.php?m_id=2&error=updated");
    }else{
        header("Location: {$hostname}admin/add-video-post.php?m_id=2&error=error");
    }
            
?>