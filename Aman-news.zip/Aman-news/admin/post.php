<?php include "header.php"; ?>
<?php
if (isset($_GET['error'])){
    $error = $_GET['error'];
if($error == 'up'){
    echo "<div class='alert alert-success'>post is succesfully Updated.</div>";
}else{
    echo "<div class='alert alert-success'>post is succesfully added.</div>";
}
}
?>
  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-10">
                  <h1 class="admin-heading">All Posts</h1>
              </div>
              <div class="col-md-2">
                  <!-- <a class="add-new" href="add-post.php?id=1">add post</a> -->
                  <a class="add-new" href="add-post.php">add post</a>
              </div>
              <div class="col-md-12">
              <?php
                    
                    $limit = 5;
                    if(isset($_GET['page1']) ){
                        $page1 = $_GET["page1"];
                    }else{
                        $page1 = 1;
                    }
                    $offset = ($page1 - 1) * $limit;
                    ?>
                  <table class="content-table">
                      <thead>
                          <th>S.No.</th>
                          <th>Title</th>
                          <th>Category</th>
                          <th>Date</th>
                          <th>Author</th>
                          <th>Edit</th>
                          <th>Delete</th>
                      </thead>
                      <tbody>
                        <?php
                        $user_id = $_SESSION['user_id'];
                        include "config.php";
                        if($_SESSION['user_role'] == 1){
                        $sql = "SELECT post.post_id, post.title, post.category, post.post_date,
                                category.category_name, category.category_id, user.username FROM post
                                LEFT JOIN category ON post.category = category.category_id 
                                LEFT JOIN user ON post.author = user.user_id
                                ORDER BY post_id DESC
                                LIMIT {$offset}, {$limit}";
                        }else{
                            $sql = "SELECT post.post_id, post.title, post.category, post.post_date,
                                category.category_name, category.category_id, user.username FROM post
                                LEFT JOIN category ON post.category = category.category_id 
                                LEFT JOIN user ON post.author = user.user_id
                                WHERE post.author = $user_id
                                ORDER BY post_id DESC
                                LIMIT {$offset}, {$limit}";
                        }        
                        $query = mysqli_query($conn, $sql);
                        $s_number =   $offset;
                        while ($row = mysqli_fetch_assoc($query)){

                        
                            $s_number++;
                        ?>
                          <tr>
                              <td class='id'><?php echo $s_number ?></td>
                              <td><?php echo $row['title'] ?></td>
                              <td><?php echo $row['category_name'] ?></td>
                              <td><?php echo $row['post_date'] ?></td>
                              <td><?php echo $row['username'] ?></td>
                              <td class='edit'><a href='update-post.php?m_id=1&id=<?php echo $row['post_id']; ?>'><i class='fa fa-edit'></i></a></td>
                              <td class='delete'><a href='delete-post.php?c_id=<?php echo $row['category']; ?>&id=<?php echo $row['post_id']; ?>'><i class='fa fa-trash-o'></i></a></td>
                          </tr>
                          <?php } ?>
                          
                      </tbody>

                  </table>
                  <?php
                    $limit = 5;
                    $s_userid = $_SESSION['user_id'];
                    if($_SESSION['user_role'] == 1){
                        $sql2 = "SELECT * FROM post";
                    }else{
                        $sql2 = "SELECT * FROM post WHERE post.author = $s_userid";
                    }
                    $query2 = mysqli_query($conn, $sql2);
                    $total_records = mysqli_num_rows($query2);
                    $total_pages = ceil($total_records / $limit);
                    echo "<ul class='pagination admin-pagination'>";
                    if($page1 > 1){
                        echo '<li><a href="post.php?page1='.($page1 - 1).'">Prev</a></li>';
                    }
                   for($j = 1; $j <= $total_pages; $j++) {
                    if($j == $page1){
                        $active = "active";
                    }
                    else{
                        $active = "";
                    }
                    echo '<li class="'.$active.'"><a href="post.php?page1='.$j.'">'.$j.'</a></li>';
                   }
                   if($total_pages > $page1){
                    echo '<li><a href="post.php?page1='.($page1 + 1).'">Next</a></li>';
                }
                   echo "</ul>";
                  ?>
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
