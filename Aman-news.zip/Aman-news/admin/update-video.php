<?php include "header.php"; ?>
<?php 
if (isset($_GET['error'])){
    $error = $_GET['error'];
    switch ($error){
        case 'vsize':
            echo "<div class='alert alert-danger'>Image size must be less than 5MB. </div>";
            break;
        case 'vextension':
            echo "<div class='alert alert-danger'>Image type must be 'jpg', 'png', 'jpeg', or 'gif'</div>";
            break;
    }
}
?>
<div id="admin-content">
  <div class="container">
  <div class="row">
    <div class="col-md-12">
        <h1 class="admin-heading">Update Video Post</h1>
    </div>
    <div class="col-md-offset-3 col-md-6">


    <?php
    
        $id = $_GET["id"];
        include "config.php";
        $sql = "SELECT video.v_id, video.v_title,video.v_description, video.v_category, video.v_date, category.category_id,
                category.category_name, user.username, video.post_video FROM video
                LEFT JOIN category ON video.v_category = category.category_id 
                LEFT JOIN user ON video.v_author = user.user_id
                WHERE video.v_id = $id";
        $result = mysqli_query($conn, $sql) or die("quer1 failed.");
        $row = mysqli_fetch_assoc($result);
    ?>
        <!-- Form for show edit-->
        <form action="save-updated-video.php?&v_id=<?php echo $row['v_category'] ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
            <div class="form-group">
                <input type="hidden" name="post_id"  class="form-control" value="<?php echo $row['v_id']; ?>" placeholder="">
            </div>
            <div class="form-group">
                <label for="exampleInputTile">Title</label>
                <input type="text" name="post_title"  class="form-control" id="exampleInputUsername" value="<?php echo  $row['v_title']; ?>">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1"> Description</label>
                <textarea name="postdesc" class="form-control"  required rows="5">
                <?php echo $row['v_description']; ?>
                </textarea>
            </div>
            <div class="form-group">
                <label for="exampleInputCategory">Category</label>
                <select class="form-control" name="category">
                    <option value="" disabled> Select category</option>

                    <?php
                        include "config.php";
                        $sql1 = "SELECT * FROM category";
                        $result1 = mysqli_query($conn, $sql1);
                        while ($row1 = mysqli_fetch_assoc($result1)) {
                        if($row['v_category'] == $row1['category_id']){
                            $selected = "selected";
                        }else{
                            $selected = "";
                        }
                        ?>
                            <option echo <?php echo $selected ?> value="<?php echo $row1['category_id'];?>"><?php echo $row1['category_name'];?></option>
                            
                        <?php
                        }
                    ?>
                </select>
            </div>
          
         
            <div class="form-group">
                <label for="">Post Video</label>
                <input type="file" name="new-image">
                <video src="upload/<?php echo $row['post_video'];     ?>" alt="" controls width='300px' height='200px'></a></video>
                <input type="hidden" name="old_image" value="<?php echo $row['post_video']; ?>">
            </div>
            <input type="submit" name="submit" class="btn btn-primary" value="Update" />
        </form>
        <!-- Form End -->
      </div>
    </div>
  </div>
</div>
<?php include "footer.php"; ?>
