<?php
include "config.php";
session_start();
if(!isset($_SESSION['username'])){
    header("Location: {$hostname}admin/index.php");
}
?>
<?php
include "config.php";
$cat_id = $_GET['id'];
$sql = "DELETE FROM category WHERE category_id = $cat_id";
$result = mysqli_query($conn, $sql) or die("Couldn't connect to database.");
header("Location: {$hostname}admin/category.php?m_id=3");

?>