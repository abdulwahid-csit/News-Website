<?php
$pr_username = strtolower($_GET['username']);
include "config.php";
    $user_id = $_POST['user_id'];
    $first_name = mysqli_real_escape_string($conn, $_POST['f_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['l_name']);
    $username = strtolower(mysqli_real_escape_string($conn, $_POST['username']));
    $role = $_POST['role'];

if(($pr_username === $username)){
    $sql1 = "UPDATE user SET first_name = '$first_name', last_name = '$last_name', username = '$username', role = '$role' WHERE user_id = $user_id";
    $query = mysqli_query($conn, $sql1) or die("mysql error");
    header("Location: {$hostname}admin/users.php?m_id=4");
    die();

}else{
    $sql1 = "SELECT * FROM user";
    $query1 = mysqli_query($conn, $sql1);
    while($row = mysqli_fetch_assoc($query1)){
        if($row['username'] == $username){
            header("Location: {$hostname}admin/update-user.php?m_id=4&error=1&id={$user_id}");
            die();
    }
}
}

$sql1 = "UPDATE user SET first_name = '$first_name', last_name = '$last_name', username = '$username', role = '$role' WHERE user_id = $user_id";
$query = mysqli_query($conn, $sql1) or die("mysql error");
header("Location: {$hostname}admin/users.php?m_id=4");

    //  if(isset($_POST["submit"])) {
    //     $user_id = $_POST['user_id'];
    //     $first_name = mysqli_real_escape_string($conn, $_POST['f_name']);
    //     $last_name = mysqli_real_escape_string($conn, $_POST['l_name']);
    //     $username = mysqli_real_escape_string($conn, $_POST['username']);
    //     $role = $_POST['role'];
    //     $sql1 = "SELECT username, user_id FROM user";
    //     $result = mysqli_query($conn, $sql1) or die("Error");
    //     while($row1 = mysqli_fetch_assoc($result)) {
    //     if($row1['username'] == $username && $row1['user_id'] != $user_id){
    //     $chk = 1;
    //     }
    //     }
    //     if($chk == 1){
    //         echo "<div class= alert alert-danger >username already exists</div>";
    //         die();
    //     }else{
    //         $sql1 = "UPDATE user SET first_name = '$first_name', last_name = '$last_name', username = '$username', role = '$role' WHERE user_id = $user_id";
    //     $query = mysqli_query($conn, $sql1) or die("mysql error");
    //     header("Location: {$hostname}admin/users.php");
    //     }
    // }         
?>