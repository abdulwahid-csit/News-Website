<?php
$conn = mysqli_connect("localhost", "root", "", "Aman_news") or die("Couldn't connect to to the server");
$hostname = "http://localhost/Aman-news/";
$admin_host = "http://localhost/Aman-news/admin/";
?>