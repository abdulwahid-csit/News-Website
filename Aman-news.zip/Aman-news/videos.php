<?php include 'header.php'; ?>
    <div id="main-content">
      <div class="container">
        <div class="row">
        <?php include 'search_video_box.php'; ?>
            <div class="col-md-8">
                <!-- post-container -->
                <div class="post-container">
                    <?php         
                        $limit = 4;
                       if(isset($_GET['page']) ){
                           $page = $_GET["page"];

                       }else{
                           $page = 1;
                       }
                       $offset = ($page -1) * $limit;
                        include "config.php";
                        $sql = "SELECT * FROM video
                                LEFT JOIN user ON video.v_author = user.user_id
                                LEFT JOIN category ON category.category_id = v_category
                                ORDER BY v_id DESC
                                LIMIT {$offset}, {$limit}";

                                $query1 = mysqli_query($conn, $sql) or die("Query failed.");
                                $query2 = mysqli_query($conn, $sql) or die("Query failed.");
                                $row = mysqli_fetch_assoc($query1);
                    
                                ?>
                    <h2 class="page-heading">Videos</h2>
                    <?php while ($row = mysqli_fetch_assoc($query2)) { 
                    ?>
                        <div class="post-content">
                        <div class="row">
                            <div class="col-md-4">
                                <a class="post-video" href="single-videos.php?id=<?php echo $row['v_id'] ?>"><video src="admin/upload/<?php echo $row['post_video']; ?>" alt="" controls width='100%' height='100%' muted></a></video>
                            </div>
                            <div class="col-md-8">
                                <div class="inner-content clearfix">
                                    <h3><a href='single-videos.php?id=<?php echo $row['v_id'] ?>'><?php echo $row['v_title']?></a></h3>
                                    <div class="post-information">
                                        <span>
                                            <i class="fa fa-tags" aria-hidden="true"></i>
                                            <a href='category.php?id=<?php echo $row['v_category'] ?>'><?php echo $row['category_name']?></a>
                                        </span>
                                        <span>
                                            <i class="fa fa-user" aria-hidden="true"></i>
                                            <a href='author.php?aid=<?php echo $row['v_author']; ?>'><?php echo $row['username']?></a>
                                        </span>
                                        <span>
                                            <i class="fa fa-calendar" aria-hidden="true"></i>
                                            <?php echo $row['v_date']?>
                                        </span>
                                    </div>
                                    <p class="description">
                                    <?php echo substr($row['v_description'], 0, 180) . "...."; ?>
                                    </p>
                                    <a class='read-more pull-right?id=' href='single-videos.php?id=<?php echo $row['v_id'] ?>'>read more</a>
                                </div>
                            </div>
                        </div>
                    </div>  
                    <?php 

                        }
                    
                    
                    ?>
                                                 
                        <?php
                            $limit = 4;
                            $sql2 = "SELECT * FROM video";
                            // $query2 = mysqli_query($conn, $sql2);
                            $result1 = mysqli_query($conn, $sql2) or die("Query failed");                
                            $total_records = mysqli_num_rows($result1);
                            $total_pages = ceil($total_records / $limit);
                            echo "<ul class='pagination admin-pagination'>";
                            if($page > 1){
                                echo '<li><a href="videos.php?page='.($page - 1).'">Prev</a></li>';
                            }
                        for($i = 1; $i <= $total_pages; $i++) {
                            if($i == $page){
                                $active = "active";
                            }
                            else{
                                $active = "";
                            }
                            echo '<li class="'.$active.'"><a href="videos.php?page='.$i.'">'.$i.'</a></li>';
                        }
                        if($total_pages > $page){
                            echo '<li><a href="videos.php?page='.($page + 1).'">Next</a></li>';
                        }
                        echo "</ul>";
                        ?>
                </div><!-- /post-container -->
            </div>
            <?php include 'sidebar-video.php'; ?>
        </div>
      </div>
    </div>
<?php include 'footer.php'; ?>
