<div id="sidebar" class="col-md-4">
    <!-- recent posts box -->
    <div class="recent-post-container">
        <h4>Recent Posts</h4>
          <?php

            include "config.php";
            $limit = 5;
            $sql = "SELECT post.post_id, post.title,post.description, post.category, post.post_date, category.category_name,
            category.category_id, post.post_img FROM post
            LEFT JOIN category ON post.category = category.category_id 
            ORDER BY post_id DESC
            LIMIT {$limit}";
            $query = mysqli_query($conn, $sql) or die("Query failed.");
            if (mysqli_num_rows($query) > 0){
    while ($row = mysqli_fetch_assoc($query)){
            $all_column = $row['post_img'];
            $all_column_array = explode('!', $all_column);
            $count = count($all_column_array);
            for($i = 0; $i < $count; $i++) {
                    ?>
                    <div class="recent-post">
                        <a class="post-img" href="single.php?id=<?php echo $$all_column_array[$i] ?>">
                            <img src="admin/upload/<?php echo $all_column_array[$i] ?>" alt=""/>
                        </a>
                        <div class="post-content">
                            <h5><a href="single.php?id=<?php echo $row['post_id'] ?>"><?php echo $row['title']; ?></a></h5>
                            <span>
                                <i class="fa fa-tags" aria-hidden="true"></i>
                                <a href='category.php?id=<?php echo $row['category_id'] ?>'><?php echo $row['category_name']; ?></a>
                            </span>
                            <span>
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <?php echo $row['post_date']; ?>
                            </span>
                            <a class="read-more" href="single.php?id=<?php echo $row['post_id'] ?>">read more</a>
                        </div>
                    </div>

                    <?php
                     break;
                }
            
            } 
            }
        ?>

    </div>
    <!-- /recent posts box -->
</div>




