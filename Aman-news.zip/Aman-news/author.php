<?php include 'header.php'; ?>
    <div id="main-content">
      <div class="container">
        <div class="row">
        <?php include 'searchbox.php'; ?>
            <div class="col-md-8">
                <!-- post-container -->
                <div class="post-container">
                <?php
                    include "config.php";     
                    if(isset($_GET["aid"]) ){
                       $auth_id = $_GET["aid"];
                   }
                   $limit = 3;
                       if(isset($_GET['page']) ){
                           $page = $_GET["page"];
                       }else{
                           $page = 1;
                       }
                       $offset = ($page -1) * $limit;
                       $sql1 = "SELECT * FROM post JOIN user
                       ON post.author = user.user_id
                       WHERE post.author = {$auth_id}";
                       $result1 = mysqli_query($conn, $sql1) or die("Query failed");
                       $row1 = mysqli_fetch_array($result1);
                       $offset = ($page -1) * $limit;  
                                $sql2 = "SELECT * FROM post
                                        LEFT JOIN category ON post.category = category.category_id 
                                        LEFT JOIN user ON post.author = user.user_id
                                        WHERE user.user_id = {$auth_id}
                                        ORDER BY post_id DESC
                                        LIMIT {$offset}, {$limit}";

                                $resul2 = mysqli_query($conn, $sql2) or die("Query failed."); 
                                ?>
                    <h2 class="page-heading"><?php echo $row1['username']; ?></h2>
                            <?php   
                             while ($row = mysqli_fetch_assoc($resul2)) {
                                 $all_images = explode('!', $row['post_img']);
                                 $limit = count($all_images);
                                 for($i=0; $i < $limit; $i++){
                                    $image = $all_images[$i];
                            ?>  
                                
                    <div class="post-content">
                        <div class="row">
                            <div class="col-md-4">
                                <a class="post-img" href="single.php?id=<?php echo $row['post_id'] ?>"><img src="./admin/upload/<?php echo $image?>" alt=""></a>
                            </div>
                            <div class="col-md-8">
                                <div class="inner-content clearfix">
                                    <h3><a href='single.php?id=<?php echo $row['post_id'] ?>'><?php echo $row['title']?></a></h3>
                                    <div class="post-information">
                                        <span>
                                            <i class="fa fa-tags" aria-hidden="true"></i>
                                            <a href='category.php?id=<?php echo $row['category_id']?>'><?php echo $row['category_name']?></a>
                                        </span>
                                        <span>
                                            <i class="fa fa-user" aria-hidden="true"></i>
                                            <a href='author.php?aid=<?php echo $row['user_id']; ?>'><?php echo $row['username']?></a>
                                        </span>
                                        <span>
                                            <i class="fa fa-calendar" aria-hidden="true"></i>
                                            <?php echo $row['post_date']; ?>
                                        </span>
                                    </div>
                                    <p class="description">
                                    <?php echo substr($row['description'], 0, 180) . "...."; ?>
                                    </p>
                                    <a class='read-more pull-right' href='single.php?id=<?php echo $row['post_id'] ?>'>read more</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php
                    break;
                    }
                    
                }
                    $sql = "SELECT * FROM video
                    LEFT JOIN category ON video.v_category = category.category_id 
                    LEFT JOIN user ON video.v_author = user.user_id
                    WHERE user.user_id = {$auth_id}
                    ORDER BY v_id DESC
                    LIMIT {$offset}, {$limit}";
                    $result = mysqli_query($conn, $sql) or die("Query failed."); 
                    while($row1 = mysqli_fetch_assoc($result)){

                    ?>
                    <div class="post-content">
                    <div class="row">
                        <div class="col-md-4">
                            <a class="post-img" href="single-videos.php?id=<?php echo $row1['v_id'] ?>"><video src="admin/upload/<?php echo $row1['post_video']; ?>" alt="" controls width="300px" height="150px"></a></video>
                        </div>
                        <div class="col-md-8">
                            <div class="inner-content clearfix">
                                <h3><a href='single-videos.php?id=<?php echo $row1['v_id'] ?>'><?php echo $row1['v_title']?></a></h3>
                                <div class="post-information">
                                    <span>
                                        <i class="fa fa-tags" aria-hidden="true"></i>
                                        <a href='category.php?id=<?php echo $row1['category_id']?>'><?php echo $row1['category_name']?></a>
                                    </span>
                                    <span>
                                        <i class="fa fa-user" aria-hidden="true"></i>
                                        <a href='author.php?aid=<?php echo $row1['user_id']; ?>'><?php echo $row1['username']?></a>
                                    </span>
                                    <span>
                                        <i class="fa fa-calendar" aria-hidden="true"></i>
                                        <?php echo $row1['v_date']; ?>
                                    </span>
                                </div>
                                <p class="description">
                                <?php echo substr($row1['v_description'], 0, 180) . "...."; ?>
                                </p>
                                <a class='read-more pull-right' href='single-videos.php?id=<?php echo $row1['v_id'] ?>'>read more</a>
                            </div>
                        </div>
                    </div>
                </div>
                    <?php
                    break;
                    }
                
                            $limit = 3;
                            $total_records = mysqli_num_rows($result1);
                            $total_pages = ceil($total_records / $limit);
                            echo "<ul class='pagination admin-pagination'>";
                            if($page > 1){
                                echo '<li><a href="author.php?aid='. $auth_id .'&page='.($page - 1).'">Prev</a></li>';
                            }
                        for($i = 1; $i <= $total_pages; $i++) {
                            if($i == $page){
                                $active = "active";
                            }
                            else{
                                $active = "";
                            }
                            echo '<li class="'.$active.'"><a href="author.php?aid='. $auth_id .'&page='.$i.'">'.$i.'</a></li>';
                        }
                        if($total_pages > $page){
                            echo '<li><a href="author.php?aid='. $auth_id .'&page='.($page + 1).'">Next</a></li>';
                        }
                        echo "</ul>";

                        ?>   
                </div>
            </div>
            <?php include 'sidebar.php'; ?>
        </div>
      </div>
    </div>
<?php include 'footer.php'; ?>
