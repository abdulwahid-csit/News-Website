

<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<meta name="viewport"
		content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="./css/about.css">
	<title>About Us</title>
</head>

<body>
    
	<header>
		<nav>
			<div class="logo">
			Aman News:
			</div>
			<ul class="nav-links">
				<li><a href="index.php">
				Home</a>
				</li>
			</ul>
		</nav>
	</header>
	<section class="about">
		<h1>About Us</h1>
		<p style="font-weight: bold">
	     <h2> Aman News website</h2>
		</p>
		<div class="about-info">
			<div class="about-img">
             <img src="./images/aman.jpg" alt="User 1">
			</div>
			<div>
			<p>  Among these news outlets, you will also find a News Site.  This is actually an Online Newspaper and a version of a printed paper.  The Internet, or going online, created more opportunities for newspapers and independent news sites not linked to a printed version.  Publishing, or Broadcasting the latest, breaking news, first, is every news outlet’s top-most priority.
                With online newspapers, anything you post is immediate, Out There, current, fresh, Now, news.
                An early version of a news site was, “News Report”, in 1974, reporting on the PLATO system.  By the late 1990s, many newspapers were also publishing an online version.  Printed newspaper versions usually run news that featured 12 hours before, on the online version.
                Topics for newsworthy events run, from war, government issues, the entertainment business, politics, health, education, global warming, sports events, unusual happenings and much more.  Anything that will bring a change in our daily lives, a change in rules and regulations by governments, taxes, celebrity celebrations, presidential or royal ceremonies, crime, all things that will gain attention, is regarded as news.
                A News Site can still use News Reporters, or journalists, to provide them with the news.  Journalists are being taught today to be able to write and shoot video that can be used for Internet news sites, as well as, the correct format used for printed versions
                But, News sites can also publish news from other sources; too, for instance, you came upon a rare bird on vacation, took a picture, and submitted it on their website.  Or, you found a lost child in a shopping centre and published it online.  All newsworthy events and publishable, experienced, first hand, by yourself.
				
			</div>
		</div>
	</section>

	<section class="team">
		<h1>Meet Our Team</h1>
		<div class="team-cards">
		
			<!-- Cards here -->
			<!-- Card 1 -->
		
			<div class="card">
				<div class="card-img">
	              <img src="./images/sss.jpg" alt="User 1">
				</div>
				<div class="card-info">
					<h2 class="card-name">Abdul Wahid</h2>
					<p class="card-role">BSCS At Hazara <br>University</p>
					<p class="card-email">abdulwahid8@gmail.com</p>
					<p><button class="button">Contact</button></p>
				</div>
			</div>

			<!-- Card 2 -->
		
			<div class="card">
				<div class="card-img">
					<img src="./images/khalidd.jpg" alt="User 2">
				</div>
				<div class="card-info">
                    <h2 class="card-name">Shah Khalid</h2>
					<p class="card-role">BSCS At Hazara <br>University</p>
					<p class="card-email">shahkhalidbcs6@gmail.com</p>
					<p><button class="button">Contact</button></p>
				</div>
			</div>
		
			<!-- Card 3 -->
		
			<div class="card">
				<div class="card-img">
				 <img src="./images/zain.jpg" alt="User 3">
				</div>
				<div class="card-info">
					<h2 class="card-name">Zain Ul Abideen</h2>
					<p class="card-role">BSCS At Hazara <br>University</p>
					<p class="card-email">zain77@gmail.com</p>
					<p><button class="button">Contact</button></p>
				</div>
			</div>
		</div>
		<a href="index.php"><h4> <button>Back</button></h4></a>
	</section>

	<footer>
		<p><b>Aman News</b></p>
	</footer>
</body>

</html>
