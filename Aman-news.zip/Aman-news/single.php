<?php include 'header.php'; ?>
    <div id="main-content">
        <div class="container">
            <div class="row">
                <?php include 'searchbox.php'; ?>
                <div class="col-md-8">
                  <!-- post-container -->
                    <div class="post-container">
                    <?php
                        $post_id = $_GET['id'];
                        include "config.php";
                        $sql = "SELECT post.post_id, post.title,post.description, post.category,
                                post.post_date, category.category_name, post.author,
                                category.category_id, user.user_id, user.username, post.post_img FROM post
                                LEFT JOIN category ON post.category = category.category_id 
                                LEFT JOIN user ON post.author = user.user_id WHERE post.post_id = $post_id" ;
                        $query = mysqli_query($conn, $sql) or die("Query failed.");
                        while ($row = mysqli_fetch_assoc($query)){
                    ?>
                        <div class="post-content single-post">
                            <h3><?php echo $row['title']; ?></h3>
                            <div class="post-information">
                                <span>
                                    <i class="fa fa-tags" aria-hidden="true"></i>
                                    <a href="category.php?id=<?php echo $row['category_id'] ?>"><?php echo $row['category_name']; ?></a>
                                </span>
                                <span>
                                    <i class="fa fa-user" aria-hidden="true"></i>
                                    <a href='author.php?aid=<?php echo $row['author']; ?>'><?php echo $row['username']; ?></a>
                                </span>
                                <span>
                                    <i class="fa fa-calendar" aria-hidden="true"></i>
                                    <?php echo $row['post_date']; ?>
                                </span>
                            </div>
                            <?php
                            $image_array = explode('!', $row['post_img']);
                            $count = count($image_array);
                            for ($i = 0; $i < $count - 1; $i++) {
                            if($i==0){
                                $first = 'first_image';
                            }else{
                                $first = '';
                            }
                            ?>
                            <img class="single-feature-image <?php echo $first ?>"   src="admin/upload/<?php echo $image_array[$i]; ?>" alt="" ></a>
                            <?php } ?> 
                            <div>
                            <?php
                            $image_array = explode('!', $row['post_img']);
                            $count = count($image_array);
                            for ($i = 0; $i < $count - 1; $i++) {
                            if($i==0){
                                $first = 'active';
                            }else{
                                $first = '';
                            }
                            ?>
                            
                            <img class="multiple-feature-image <?php echo $first ?>" src="admin/upload/<?php echo $image_array[$i]; ?>" alt="" ></a>
                            <?php } ?>  
                            </div>
                            <p class="description">
                            <?php echo $row['description']; ?>
                            </p>
                            </div>
                            
                        </div>
                        <?php } ?>
                    </div>
                    <!-- /post-container -->
                    <?php include 'sidebar.php'; ?>
                </div>
            </div>
        </div>
    </div>
    <script src="./JS/main.js"></script>
<?php include 'footer.php'; ?>
